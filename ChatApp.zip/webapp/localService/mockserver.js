sap.ui.define([
	"sap/ui/core/util/MockServer"
	], function (MockServer) {
    "use strict";
    return {
        init: function () {
            // create
            var oMockServer = new MockServer({
                // rootUri: ""
                rootUri: "/mock/"
            });
            var oUriParameters = jQuery.sap.getUriParameters();
            // configure
            MockServer.config({
                autoRespond: true,
                autoRespondAfter: oUriParameters.get("serverDelay") || 1000
            });
            oMockServer.attachAfter(sap.ui.core.util.MockServer.HTTPMETHOD.GET,function(oEvent){
            	var oData = oEvent.getParameter('oFilterData').results;
            });
            // simulate
            var sPath = jQuery.sap.getModulePath("ChatApp.localService");
            // oMockServer.simulate(sPath + "/metadata.xml", sPath);
             oMockServer.simulate(sPath + "/metadata.xml", sPath + "/mockdata");
            // start
            oMockServer.start();
        }
    };
});