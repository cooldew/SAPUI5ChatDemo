sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ChatApp/model/models",
	"ChatApp/localService/mockserver",
	"sap/f/library",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/util/MockServer"
], function(UIComponent, Device, models, mockserver, fioriLibrary, JSONModel, MockServer) {
	"use strict";

	return UIComponent.extend("ChatApp.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			var oModel,
				oRouter,
				url,
				odataModel;
			
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			// this.setModel(models.createDeviceModel(), "device");
			oModel = new JSONModel();
			this.setModel(oModel);
			
			// mockserver.init(); 
			
			//mockserver ---------
	            var oMockServer = new MockServer({
	                // rootUri: ""
	                rootUri: "/test/"
	            });
	            var oUriParameters = jQuery.sap.getUriParameters();
	            // configure
	            MockServer.config({
	                autoRespond: true,
	                autoRespondAfter: oUriParameters.get("serverDelay") || 1000
	            });
	            // oMockServer.attachAfter(sap.ui.core.util.MockServer.HTTPMETHOD.GET,function(oEvent){
	            // 	var oData = oEvent.getParameter('oFilterData').results;
	            // });
	            // simulate
	            var sPath = jQuery.sap.getModulePath("ChatApp.localService");
	            // oMockServer.simulate(sPath + "/metadata.xml", sPath);
	             oMockServer.simulate(sPath + "/metadata.xml", sPath + "/mockdata");
	            // start
	            oMockServer.start();
	            url = "/test/";
	            var chatsSetArray = oMockServer.getEntitySetData('chatsSet');
	            var ReceivedMessagesSetArray = oMockServer.getEntitySetData('ReceivedMessagesSet');
	            var SentMessagesSetArray = oMockServer.getEntitySetData('SentMessagesSet');
	            
	            var JsonModel = new JSONModel();
	            JsonModel.setProperty("/chatsSet",chatsSetArray);
	            JsonModel.setProperty("/ReceivedMessagesSet",ReceivedMessagesSetArray);
	            JsonModel.setProperty("/SentMessagesSet",SentMessagesSetArray);
			//mockserver ---------
			
			
			// url = "/mock/"
		    odataModel = new sap.ui.model.odata.v2.ODataModel(url);
		    // this.setModel(odataModel,"mockDataModel"); 
		    this.setModel(JsonModel,"mockDataModel");
			
			oRouter = this.getRouter();
			oRouter.attachBeforeRouteMatched(this._onBeforeRouteMatched, this);
			oRouter.initialize();
		},
		_onBeforeRouteMatched: function(oEvent) {
			var oModel = this.getModel("mockDataModel"),
				sLayout = oEvent.getParameters().arguments.layout;

			// If there is no layout parameter, set a default layout (normally OneColumn)
			if (!sLayout) {
				sLayout = fioriLibrary.LayoutType.OneColumn;//OneColumn;//TwoColumnsMidExpanded
			}

			oModel.setProperty("/layout", sLayout);
		}
	});
});