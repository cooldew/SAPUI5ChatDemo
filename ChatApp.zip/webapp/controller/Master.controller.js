sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
    "sap/f/library"
], function (Controller, Filter, FilterOperator, Sorter, MessageBox, JSONModel, fioriLibrary) {
	"use strict";

	return Controller.extend("ChatApp.controller.Master", {
		onInit: function () {
			this.oView = this.getView();
			this._bDescendingSort = false;
			this.oProductsTable = this.oView.byId("personTable");
			this.oRouter = this.getOwnerComponent().getRouter();
			
		    var odataModel = this.getOwnerComponent().getModel("mockDataModel");
		    this.getView().setModel(odataModel);
		},

		onSearch: function (oEvent) {
			var oTableSearchState = [],
				sQuery = oEvent.getParameter("query");

			if (sQuery && sQuery.length > 0) {
				oTableSearchState = [new Filter("contactName", FilterOperator.Contains, sQuery)];
			}

			this.oProductsTable.getBinding("items").filter(oTableSearchState, "Application");
		},
		onListItemPress: function (oEvent) {
			// var oFCL = this.oView.getParent().getParent();
			// oFCL.setLayout(fioriLibrary.LayoutType.TwoColumnsMidExpanded);
			
			var odataModel = this.getOwnerComponent().getModel("mockDataModel");
		    var chatsSetModel = odataModel.getProperty("/chatsSet");
		    var array_tmp;
		    var phone;
		    array_tmp = oEvent.getSource().getBindingContext().sPath.split("/").slice(-1);
		    phone = chatsSetModel[array_tmp[0]].phone;

			this.oRouter.navTo("detail", {phone: phone});
		}
	});
});