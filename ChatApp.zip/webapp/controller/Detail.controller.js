sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function (Controller, Filter, FilterOperator, JSONModel) {
	"use strict";
	
	 var JsonModel;

	return Controller.extend("ChatApp.controller.Detail", {
		onInit: function () {
			this.oSentMsgTable = this.oView.byId("sentMsgTable");
			
			var oOwnerComponent = this.getOwnerComponent();
			this.oRouter = oOwnerComponent.getRouter();
		
			this.oRouter.getRoute("master").attachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").attachPatternMatched(this._onProductMatched, this);
		},

		_onProductMatched: function (oEvent) {
			var person;
			person = oEvent.getParameter("arguments").phone;// || this._product || "0";
				var odataModel = this.getOwnerComponent().getModel("mockDataModel");
				
		        var chatsSetModel = odataModel.getProperty("/chatsSet");
		        var sentMessagesModel = odataModel.getProperty("/SentMessagesSet");
		        var receiverMessageModel = odataModel.getProperty("/ReceivedMessagesSet");
		        // console.log(chatsSetModel);
	
			    var chatMsg = new Array();
		        var entryLine;
		        chatsSetModel.forEach(function(currentValue, index0, arr0){
		        	if (person === currentValue.phone){
		        	// console.log(currentValue);
		             sentMessagesModel.forEach(function(currentValueSent, index1, arr1){
		            	if (person === currentValueSent.phone){
		            		entryLine = {  id: currentValueSent.id, 
                                           date_sent: currentValueSent.date, 
			              	               date_receive: '', 
			              	               date: currentValueSent.date,
			              	               text_sent: currentValueSent.text, 
			              	               text : currentValueSent.text,
			              	               text_receive : '',
			              	               phone: currentValueSent.phone, 
			              	               sent: currentValueSent.sent, 
			              	               delivered: currentValueSent.delivered,
			              	               read: currentValueSent.read,
			              	               place: 'right',
			              	               icon: currentValue.photo
		              	              };
		            	  chatMsg.push(entryLine);	
		            	}
		              	              		
		             });
		             
		             receiverMessageModel.forEach(function(currentValueRecv, index1, arr1){
		            	if (person === currentValueRecv.phone){
		            		entryLine = {  id: currentValueRecv.id, 
			              	               date_sent: '', 
			              	               date_receive: currentValueRecv.date, 
			              	               date: currentValueRecv.date,
			              	               text_sent : '',
			              	               text : currentValueRecv.text,
			              	               text_receive: currentValueRecv.text, 
			              	               phone: currentValueRecv.phone,
			              	               place: 'left',
			              	               icon: currentValue.photo
		              	              };
		            	  chatMsg.push(entryLine);	
		            	}
		              	              		
		             });
		        	}
	
		            });
		        JsonModel = new JSONModel();
		        JsonModel.setProperty("/msgSentReceive",chatMsg);
		        this.getView().setModel(JsonModel);
		        this.getView().getModel().refresh(true);
		},

		onEditToggleButtonPress: function() {

		},

		onExit: function () {
			this.oRouter.getRoute("master").detachPatternMatched(this._onProductMatched, this);
			this.oRouter.getRoute("detail").detachPatternMatched(this._onProductMatched, this);
		}
	});
});